"""Лабораторна робота: типи та структури даних у Python.

Тема: Імплементація та маніпуляції основними типами та структурами даних.
Запуск: python main.py

У роботі використовуються лише вбудовані структури Python і стандартна бібліотека.
"""

from __future__ import annotations

import re
import timeit
from pathlib import Path
from typing import Iterable


BASE_DIR = Path(__file__).resolve().parent
TEXT_FILE = BASE_DIR / "input_text.txt"


def print_section(title: str) -> None:
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def task_1_lists() -> None:
    """Завдання 1. Демонстрація індексації, зрізів і мутацій списку."""
    print_section("Завдання 1. Списки: індексація, зрізи та мутації")

    numbers = [12, 7, 19, 4, 25, 8, 16, 3, 21, 10]
    print(f"Початковий список: {numbers}")

    print(f"Додатний індекс numbers[2]: {numbers[2]}")
    print(f"Від'ємний індекс numbers[-1]: {numbers[-1]}")

    # Зрізи створюють нові спискові об'єкти.
    print(f"Зріз numbers[1:6]: {numbers[1:6]}")
    print(f"Зріз numbers[::2] (крок 2): {numbers[::2]}")
    print(f"Зріз numbers[8:2:-2] (зворотний крок): {numbers[8:2:-2]}")

    numbers.append(30)
    print(f"Після append(30): {numbers}; довжина = {len(numbers)}")

    numbers.insert(2, 14)
    print(f"Після insert(2, 14): {numbers}; довжина = {len(numbers)}")

    numbers.remove(4)
    print(f"Після remove(4): {numbers}; довжина = {len(numbers)}")

    numbers[3:5] = [100, 101]
    print(f"Після заміни зрізу numbers[3:5] = [100, 101]: {numbers}; довжина = {len(numbers)}")

    print("Пояснення: зрізи вище створили нові списки, а append/insert/remove/заміна зрізу змінили існуючий список на місці.")


def unpack_product(product: tuple[int, str, int, float]) -> tuple[int, str, int, float]:
    """Повертає поля товару через розпакування кортежу."""
    product_id, name, quantity, price = product
    return product_id, name, quantity, price


def total_inventory_value(products: Iterable[tuple[int, str, int, float]]) -> float:
    """Обчислює загальну вартість товарів на складі."""
    total = 0.0
    for product in products:
        _product_id, _name, quantity, price = unpack_product(product)
        total += quantity * price
    return total


def products_to_dicts(products: Iterable[tuple[int, str, int, float]]) -> list[dict[str, int | str | float]]:
    """Необов'язкове ускладнення: перетворення списку кортежів на список словників."""
    return [
        {"id": product_id, "name": name, "quantity": quantity, "price": price}
        for product_id, name, quantity, price in products
    ]


def task_2_tuples() -> None:
    """Завдання 2. Кортежі, розпакування та іммутабельність."""
    print_section("Завдання 2. Кортежі та розпакування даних")

    products = [
        (101, "Notebook", 12, 34.50),
        (102, "Mouse", 25, 12.90),
        (103, "Keyboard", 8, 45.00),
        (104, "USB cable", 30, 5.50),
    ]

    print("Модель запису: (ідентифікатор, назва, кількість, ціна за одиницю)")
    print(f"{'ID':<6}{'Назва':<14}{'Кількість':>10}{'Ціна':>12}{'Вартість':>14}")
    print("-" * 56)
    for product in products:
        product_id, name, quantity, price = unpack_product(product)
        print(f"{product_id:<6}{name:<14}{quantity:>10}{price:>12.2f}{quantity * price:>14.2f}")

    total = total_inventory_value(products)
    print(f"Загальна вартість складу: {total:.2f} грн")

    print("\nДемонстрація заборони зміни елемента кортежу:")
    example_product = products[0]
    try:
        # Цей рядок навмисно викликає TypeError, бо tuple не підтримує присвоєння за індексом.
        example_product[2] = 99  # type: ignore[index]
    except TypeError as error:
        print(f"Помилка очікувана: {error}")

    print("\nКортеж із вкладеним мутабельним списком:")
    student = ("Іваненко", "ІПЗ-21", [85, 90, 78])
    print(f"До зміни вкладеного списку: {student}")
    student[2].append(95)
    print(f"Після append(95) у вкладений список: {student}")
    print("Пояснення: сам кортеж не замінюється, але список всередині нього залишається мутабельним.")

    print("\nПеретворення кортежів на словники:")
    print(products_to_dicts(products))


def normalize_words(text: str) -> list[str]:
    """Повертає список нормалізованих слів.

    Правила: нижній регістр; слова складаються з українських/латинських літер
    та апострофа; розділові знаки відкидаються.
    """
    pattern = r"[A-Za-zА-Яа-яІіЇїЄєҐґ']+"
    return re.findall(pattern, text.lower())


def build_frequency_dict(words: Iterable[str]) -> dict[str, int]:
    """Будує словник частот без collections.Counter."""
    frequencies: dict[str, int] = {}
    for word in words:
        frequencies[word] = frequencies.get(word, 0) + 1
    return frequencies


def task_3_dicts() -> None:
    """Завдання 3. Словник частот."""
    print_section("Завдання 3. Словники та облік частот")

    if not TEXT_FILE.exists():
        raise FileNotFoundError(f"Не знайдено файл з текстом: {TEXT_FILE}")

    text = TEXT_FILE.read_text(encoding="utf-8")
    words = normalize_words(text)
    frequencies = build_frequency_dict(words)

    print(f"Файл-джерело: {TEXT_FILE.name}")
    print(f"Кількість слів після нормалізації: {len(words)}")
    print(f"Кількість унікальних слів: {len(frequencies)}")

    missing_key = "алгоритм"
    print(f"Безпечне отримання частоти для відсутнього/можливого ключа '{missing_key}': {frequencies.get(missing_key, 0)}")

    print("\nВивід за алфавітом:")
    for key in sorted(frequencies):
        print(f"{key:<15} -> {frequencies[key]}")

    print("\nВивід за спаданням частоти:")
    for key, value in sorted(frequencies.items(), key=lambda item: (-item[1], item[0])):
        print(f"{key:<15} -> {value}")

    threshold = 2
    frequent_words = {word: count for word, count in frequencies.items() if count >= threshold}
    print(f"\nПохідний словник через dict comprehension, частота >= {threshold}:")
    print(dict(sorted(frequent_words.items())))


def task_4_sets() -> None:
    """Завдання 4. Множини та операції над наборами."""
    print_section("Завдання 4. Множини: унікальність та операції")

    group_a = ["ID001", "ID002", "ID003", "ID002", "ID005", "ID006"]
    group_b = ["ID003", "ID004", "ID005", "ID007", "ID007"]
    group_c = ["ID003", "ID005"]

    set_a = set(group_a)
    set_b = set(group_b)
    set_c = set(group_c)

    print(f"Вхідна колекція A: {group_a}")
    print(f"Унікальні A: {sorted(set_a)}")
    print(f"Вхідна колекція B: {group_b}")
    print(f"Унікальні B: {sorted(set_b)}")
    print(f"Вхідна колекція C: {group_c}")
    print(f"Унікальні C: {sorted(set_c)}")

    print(f"Перетин A & B: {sorted(set_a & set_b)}")
    print(f"Об'єднання A | B: {sorted(set_a | set_b)}")
    print(f"Симетрична різниця A ^ B: {sorted(set_a ^ set_b)}")

    print(f"C є підмножиною A: {set_c <= set_a}")
    print(f"B є підмножиною A: {set_b <= set_a}")

    rights_by_group = {frozenset(set_c): "спільні ідентифікатори для A та B"}
    print(f"Приклад frozenset як ключ словника: {rights_by_group}")

    print("Пояснення: set доцільний, коли потрібні унікальність елементів і швидка перевірка належності.")


def average_time_seconds(callback, *, repeats: int = 3, number: int = 1) -> float:
    """Повертає середній час виконання callback за repeats вимірювань."""
    measurements = timeit.repeat(callback, repeat=repeats, number=number)
    return sum(measurements) / len(measurements)


def build_unique_with_list(data: list[int]) -> list[int]:
    """Унікальні значення через список і перевірку дублікатів: у гіршому випадку O(n^2)."""
    unique_values: list[int] = []
    for value in data:
        if value not in unique_values:
            unique_values.append(value)
    return unique_values


def build_unique_with_set(data: list[int]) -> set[int]:
    """Унікальні значення через множину: у середньому O(n)."""
    unique_values: set[int] = set()
    for value in data:
        unique_values.add(value)
    return unique_values


def task_5_complexity() -> list[dict[str, float | int]]:
    """Завдання 5. Порівняння часу виконання типових операцій."""
    print_section("Завдання 5. Алгоритмічна складність")

    sizes = [100, 1_000, 10_000]
    membership_checks = 5_000
    results: list[dict[str, float | int]] = []

    for n in sizes:
        list_data = list(range(n))
        set_data = set(list_data)
        dict_data = {value: value * 2 for value in list_data}
        target = n - 1
        duplicated_data = [value % (n // 2) for value in range(n)]

        list_membership_ms = average_time_seconds(
            lambda: target in list_data,
            repeats=3,
            number=membership_checks,
        ) * 1000
        set_membership_ms = average_time_seconds(
            lambda: target in set_data,
            repeats=3,
            number=membership_checks,
        ) * 1000
        dict_key_ms = average_time_seconds(
            lambda: target in dict_data,
            repeats=3,
            number=membership_checks,
        ) * 1000
        unique_list_ms = average_time_seconds(
            lambda: build_unique_with_list(duplicated_data),
            repeats=3,
            number=1,
        ) * 1000
        unique_set_ms = average_time_seconds(
            lambda: build_unique_with_set(duplicated_data),
            repeats=3,
            number=1,
        ) * 1000

        results.append(
            {
                "n": n,
                "list_membership_ms": list_membership_ms,
                "set_membership_ms": set_membership_ms,
                "dict_key_ms": dict_key_ms,
                "unique_list_ms": unique_list_ms,
                "unique_set_ms": unique_set_ms,
            }
        )

    print("Одиниці: мілісекунди. Для list/set/dict membership виміряно блок із 5000 перевірок.")
    print(
        f"{'n':>8} | {'list in':>12} | {'set in':>12} | {'dict key':>12} | "
        f"{'unique list':>14} | {'unique set':>12}"
    )
    print("-" * 87)
    for row in results:
        print(
            f"{int(row['n']):>8} | "
            f"{row['list_membership_ms']:>12.4f} | "
            f"{row['set_membership_ms']:>12.4f} | "
            f"{row['dict_key_ms']:>12.4f} | "
            f"{row['unique_list_ms']:>14.4f} | "
            f"{row['unique_set_ms']:>12.4f}"
        )

    print("\nВисновок: пошук у списку зростає разом із n, бо це лінійний перегляд.")
    print("Для set і dict перевірка належності/ключа в середньому близька до O(1).")
    print("Побудова унікальних значень через список із перевіркою дублікатів значно повільніша, ніж через set.")
    return results


def main() -> None:
    task_1_lists()
    task_2_tuples()
    task_3_dicts()
    task_4_sets()
    task_5_complexity()


if __name__ == "__main__":
    main()
